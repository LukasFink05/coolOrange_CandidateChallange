﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace coolOrange_CandidateChallenge
{
    public class Array
    {
        public static int FindMaxValue(int[] array, int pos1, int pos2)
        {
            int ret = array[pos1];
            for(int i = pos1; i <= pos2; i++)
            {
                if (array[i] > ret) ret = array[i];
            }
            return ret;
        }

        public static int FindMinPosition(int[] array, int pos1, int pos2)
        {
            int ret = pos1;
            for(int i = pos1; i <= pos2; i++)
            {
                if (array[ret] > array[i]) ret = i;
            }
            return ret + pos1; ;
        }

        public static void Swap(int[] array, int pos1, int pos2)
        {
            int temp = array[pos1];
            array[pos1] = array[pos2];
            array[pos2] = temp;
        }
        public static void ShiftLeftByOne(int[] array, int pos1, int pos2)
        {
            for(int i = pos1; i < pos2; i++)
            {
                array[i] = array[i + 1];
            }
        }

        public static int[] createRandomArray(int size, int maxValue, int minValue)
        {
            int[] returnArray = new int[size];
            Random randomGenerator = new Random();

            for(int i = 0; i < returnArray.Length; i++)
            {
               // returnArray[i] = randomGenerator.Next(minValue, maxValue);
            }
            return returnArray;
        }

        public static int[,] createRandomMatrix(int rows, int cols, int minValue, int maxValue)
        {
            int[,] returnArray = new int[rows, cols];
            Random randomGenerator = new Random();

            for(int i = 0; i < rows; i++)
            {
                for(int j = 0; j < cols; j++)
                {
                    returnArray[i,j] = randomGenerator.Next(minValue, maxValue);
                }
            }

            return returnArray;
        }

        public static int[,] copyArray(int[] array)
        {
            int[,] returnArray = new int[array.Length, array.Length];

            for(int i = 0; i < array.Length; i++)
            {
                returnArray[i, 0] = array[i];
                returnArray[i, 1] = array[i];
            }
            return returnArray;
        }
    }
}
