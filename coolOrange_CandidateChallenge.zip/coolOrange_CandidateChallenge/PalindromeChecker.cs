﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace coolOrange_CandidateChallenge
{
    public class PalindromeChecker
    {
        public static bool IsPalindrome(string s)
        {
            return recursiveIsPalindrome(s, 0, s.Length - 1);


        }
        private static bool recursiveIsPalindrome(string str, int start, int end)
        {
            if (start >= end)
            {
                return true;
            }

            if (str[start] != str[end])
            {
                return false;
            }

            return recursiveIsPalindrome(str, start + 1, end - 1);
        }
    }
}
