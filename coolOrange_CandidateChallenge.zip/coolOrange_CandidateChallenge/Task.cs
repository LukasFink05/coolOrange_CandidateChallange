interface IPriority{
    int MIN_PRIORITY;
    int MED_PRIORITY;
    int MAX_PRIORITY;

    void setPriotity();
    void getPriority;
}

interface IComplexity{
    void setComplexity();
    void getComplexity();
}

interface IComparable{
    void CompareTo();
}

class Task : IPriority, IComplexity, IComparable {
    String name;
    int priority;
    int complexity;

    Task(String name){
        this.name = name;
        priority = MED_PRIORITY;
    }
}

