class TaskDriver{
    static void main(string[] args){
        Task t1 = new Task("Do Homework");
        Task t2 = new Task("Do Dishes");
        Task t3 = new Task("Eat Lunch");
    }
}